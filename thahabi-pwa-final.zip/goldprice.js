// ============================================================
// goldprice.js — نظام جلب سعر الذهب التلقائي
// يعمل مع index.html و admin.html
// لا تعدّل هذا الملف إلا إذا أردت تغيير مصادر API
// ============================================================

// ===== الثوابت =====
const TROY          = 31.1035;   // وزن الأونصة بالغرام
const REFRESH_SEC   = 60;        // تحديث كل 60 ثانية
const CHANGE_THRESH = 0.5;       // لا تحدث Firebase إذا التغيير أقل من 0.5$

// ===== المتغيرات العامة =====
window.lastGoldPrice  = 0;       // آخر سعر تم جلبه
window.currentOunce   = 0;       // السعر الحالي
window.currentDollar  = 0;       // سعر الدولار
window.goldCountdown  = REFRESH_SEC;
window._goldInterval  = null;
window._cdInterval    = null;
window._onPriceChange = null;    // callback عند تغير السعر

// ===== مصادر API (gold-api.com أولاً، ثم احتياطية) =====
const SOURCES = [

  // المصدر 1: gold-api.com — مجاني، لحظي، بدون مفتاح API
  async () => {
    const r = await fetch(
      "https://api.gold-api.com/price/XAU",
      { signal: AbortSignal.timeout(6000) }
    );
    if (!r.ok) throw new Error("gold-api failed");
    const d = await r.json();
    if (d?.price && d.price > 500) return parseFloat(parseFloat(d.price).toFixed(2));
    throw new Error("invalid data");
  },

  // المصدر 2: Frankfurter — XAU إلى USD (احتياطي)
  async () => {
    const r = await fetch(
      "https://api.frankfurter.app/latest?from=XAU&to=USD",
      { signal: AbortSignal.timeout(6000) }
    );
    if (!r.ok) throw new Error("frankfurter failed");
    const d = await r.json();
    if (d?.rates?.USD && d.rates.USD > 500) return parseFloat(d.rates.USD.toFixed(2));
    throw new Error("invalid data");
  },

  // المصدر 3: Open Exchange Rates (احتياطي)
  async () => {
    const r = await fetch(
      "https://open.er-api.com/v6/latest/XAU",
      { signal: AbortSignal.timeout(6000) }
    );
    if (!r.ok) throw new Error("openexchange failed");
    const d = await r.json();
    if (d?.rates?.USD && d.rates.USD > 500) return parseFloat(d.rates.USD.toFixed(2));
    throw new Error("invalid data");
  }
];

// ===== جلب سعر الأونصة =====
async function fetchGoldPrice() {
  for (let i = 0; i < SOURCES.length; i++) {
    try {
      const price = await SOURCES[i]();
      if (price && price > 500) {
        console.log("✅ تم جلب سعر الذهب من المصدر " + (i+1) + ":", price);
        return price;
      }
    } catch (e) {
      console.log("⚠️ فشل المصدر " + (i+1) + ":", e.message);
    }
  }
  console.log("❌ تعذّر تحديث السعر حالياً — كل المصادر فشلت");
  return null; // كل المصادر فشلت
}

// ===== حساب مقدار التغيير =====
function calcChange(newPrice, oldPrice) {
  if (!oldPrice || oldPrice === 0) return null;
  const diff = newPrice - oldPrice;
  const pct  = ((diff / oldPrice) * 100).toFixed(2);
  return { diff: parseFloat(diff.toFixed(2)), pct: parseFloat(pct) };
}

// ===== تحديث واجهة التغيير =====
function updateChangeUI(change) {
  const el = document.getElementById("gold-change-bar");
  if (!el || !change) return;

  const isUp   = change.diff > 0;
  const icon   = isUp ? "⬆️" : "⬇️";
  const label  = isUp ? "ارتفع" : "انخفض";
  const cls    = isUp ? "up" : "down";
  const sign   = isUp ? "+" : "";
  const color  = isUp ? "#2ECC71" : "#E74C3C";

  el.className = "change-bar " + cls;
  el.style.display = "flex";
  el.innerHTML = `
    <div class="change-left">
      <span class="change-icon">${icon}</span>
      <div>
        <div class="change-label">سعر الأونصة ${label}</div>
        <div class="change-amount ${cls}">${sign}${change.diff.toLocaleString("en-US")} $</div>
      </div>
    </div>
    <span class="change-pct ${cls}">${sign}${change.pct}%</span>
  `;
}

// ===== تحديث العداد التنازلي =====
function updateCountdownUI(sec) {
  const el = document.getElementById("gold-countdown");
  if (el) el.textContent = sec + "ث";
  const fill = document.getElementById("gold-cd-fill");
  if (fill) fill.style.width = ((sec / REFRESH_SEC) * 100) + "%";
}

// ===== تحديث وقت آخر تحديث =====
function updateLastUpdateUI() {
  const el = document.getElementById("gold-last-update");
  if (!el) return;
  const now = new Date();
  el.textContent = "آخر تحديث: " + now.toLocaleTimeString("ar-IQ", {
    hour: "2-digit", minute: "2-digit"
  });
}

// ===== الدالة الرئيسية للتحديث =====
window.runGoldUpdate = async function(silent = true) {
  // تحديث حالة الاتصال
  const statusEl = document.getElementById("gold-api-status");
  if (statusEl && !silent) {
    statusEl.textContent = "⏳ جاري التحديث...";
    statusEl.style.color = "#D4A017";
  }

  const newPrice = await fetchGoldPrice();

  if (!newPrice) {
    // فشل جلب السعر
    if (statusEl) {
      statusEl.textContent = "⚠️ تعذّر تحديث السعر حالياً";
      statusEl.style.color = "#E74C3C";
    }
    return false;
  }

  // ===== حماية: لا تحدث إذا لم يتغير السعر =====
  const change = calcChange(newPrice, window.lastGoldPrice);
  const priceChanged = !window.lastGoldPrice ||
    Math.abs(newPrice - window.lastGoldPrice) >= CHANGE_THRESH;

  if (!priceChanged) {
    if (statusEl) {
      statusEl.textContent = "✅ السعر لم يتغير";
      statusEl.style.color = "#2ECC71";
    }
    updateLastUpdateUI();
    return true;
  }

  // تحديث السعر
  window.lastGoldPrice = window.currentOunce > 0 ? window.currentOunce : newPrice;
  window.currentOunce  = newPrice;

  // تحديث UI
  if (statusEl) {
    statusEl.textContent = "✅ مباشر";
    statusEl.style.color = "#2ECC71";
  }

  // عرض سعر الأونصة
  const ounceEl = document.getElementById("live-ounce-price");
  if (ounceEl) {
    ounceEl.textContent = newPrice.toLocaleString("en-US");
    ounceEl.classList.add("price-flash");
    setTimeout(() => ounceEl.classList.remove("price-flash"), 600);
  }

  // عرض مؤشر التغيير
  if (change) updateChangeUI(change);

  updateLastUpdateUI();

  // إعادة حساب أسعار الذهب
  if (window.currentDollar > 0) {
    const gram24 = (newPrice / TROY) * window.currentDollar;
    const gram21 = gram24 * 21 / 24;
    const mithqal = gram21 * 5;

    // تحديث عناصر الصفحة
    const g21El = document.getElementById("gram21");
    if (g21El && g21El.className !== "gram-price loading") {
      g21El.textContent = Math.round(gram21).toLocaleString("en-US");
      g21El.classList.add("price-flash");
      setTimeout(() => g21El.classList.remove("price-flash"), 600);
    }

    const mqFull = document.getElementById("mq-full");
    if (mqFull) mqFull.textContent = Math.round(mithqal).toLocaleString("en-US");
    const mqHalf = document.getElementById("mq-half");
    if (mqHalf) mqHalf.textContent = Math.round(mithqal / 2).toLocaleString("en-US");
    const mqQtr = document.getElementById("mq-qtr");
    if (mqQtr) mqQtr.textContent = Math.round(mithqal / 4).toLocaleString("en-US");

    // تحديث جميع العيارات
    const karats = [{k:24},{k:22},{k:21},{k:19},{k:18},{k:14}];
    karats.forEach(({k}) => {
      const el = document.getElementById("karat-price-" + k);
      if (el) el.textContent = Math.round(gram24 * k / 24).toLocaleString("en-US");
    });
  }

  // تشغيل callback خارجي إذا موجود (مثل تحديث Firebase في admin)
  if (typeof window._onPriceChange === "function" && priceChanged) {
    window._onPriceChange(newPrice, change);
  }

  return true;
};

// ===== تشغيل نظام التحديث التلقائي =====
window.startGoldAutoUpdate = function() {
  // جلب فوري عند البدء
  window.runGoldUpdate(false);

  // تحديث كل 60 ثانية
  clearInterval(window._goldInterval);
  window._goldInterval = setInterval(() => {
    window.runGoldUpdate(true);
    window.goldCountdown = REFRESH_SEC;
  }, REFRESH_SEC * 1000);

  // عداد تنازلي كل ثانية
  clearInterval(window._cdInterval);
  window._cdInterval = setInterval(() => {
    window.goldCountdown = Math.max(0, window.goldCountdown - 1);
    updateCountdownUI(window.goldCountdown);
    if (window.goldCountdown === 0) window.goldCountdown = REFRESH_SEC;
  }, 1000);
};
