// ============================================================
// service-worker.js — تطبيق ذهبي
// يجعل التطبيق يعمل بسرعة وجزئياً بدون إنترنت
// ============================================================

const CACHE_NAME = "thahabi-cache-v1";

// الملفات الأساسية التي تُحفظ للعمل بدون إنترنت
const ASSETS_TO_CACHE = [
  "/",
  "/index.html",
  "/goldprice.js",
  "/manifest.json",
  "/icons/icon-72.png",
  "/icons/icon-96.png",
  "/icons/icon-128.png",
  "/icons/icon-144.png",
  "/icons/icon-152.png",
  "/icons/icon-192.png",
  "/icons/icon-384.png",
  "/icons/icon-512.png"
];

// ===== التثبيت: حفظ الملفات الأساسية =====
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch(() => {
        // إذا فشل أحد الملفات، استمر بدون توقف
      });
    })
  );
  self.skipWaiting();
});

// ===== التفعيل: حذف الكاش القديم =====
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) return caches.delete(key);
        })
      )
    )
  );
  self.clients.claim();
});

// ===== استراتيجية الجلب =====
// للملفات الأساسية: Cache First (سرعة)
// لطلبات Firebase والـ API: Network First (بيانات حديثة)
self.addEventListener("fetch", (event) => {
  const url = event.request.url;

  // لا تتدخل في طلبات Firebase أو APIs الخارجية للأسعار
  if (
    url.includes("firebaseio.com") ||
    url.includes("firebasedatabase.app") ||
    url.includes("googleapis.com") ||
    url.includes("gstatic.com") ||
    url.includes("frankfurter.app") ||
    url.includes("er-api.com") ||
    url.includes("exchangerate-api.com") ||
    url.includes("gold-api.com")
  ) {
    return; // اترك المتصفح يتعامل معها مباشرة (بيانات حية دائماً)
  }

  // لطلبات GET فقط من نفس الموقع
  if (event.request.method !== "GET") return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) {
        // أرجع النسخة المحفوظة فوراً (سرعة)
        // وحدّث الكاش بالخلفية
        fetch(event.request)
          .then((res) => {
            if (res && res.status === 200) {
              caches.open(CACHE_NAME).then((cache) => cache.put(event.request, res));
            }
          })
          .catch(() => {});
        return cached;
      }
      // إذا لم يكن محفوظاً، اجلب من الشبكة واحفظه
      return fetch(event.request)
        .then((res) => {
          if (res && res.status === 200) {
            const resClone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, resClone));
          }
          return res;
        })
        .catch(() => {
          // إذا لا يوجد إنترنت ولا كاش، أرجع الصفحة الرئيسية كحل أخير
          if (event.request.mode === "navigate") {
            return caches.match("/index.html");
          }
        });
    })
  );
});
